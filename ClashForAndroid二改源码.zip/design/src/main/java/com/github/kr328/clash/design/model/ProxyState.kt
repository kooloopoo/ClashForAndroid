package com.github.kr328.clash.design.model

data class ProxyState(var now: String)