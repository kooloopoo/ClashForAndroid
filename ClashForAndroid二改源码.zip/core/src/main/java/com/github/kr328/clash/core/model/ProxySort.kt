package com.github.kr328.clash.core.model

enum class ProxySort {
    Default, Title, Delay
}
