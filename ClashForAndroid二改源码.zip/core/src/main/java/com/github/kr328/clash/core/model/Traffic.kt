package com.github.kr328.clash.core.model

typealias Traffic = Long